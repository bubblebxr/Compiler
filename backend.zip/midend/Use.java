package midend;

public class Use {
}
