package backend.Instruction;


/**
 * @className: MipsInstruction
 * @author: bxr
 * @date: 2024/11/21 20:45
 * @description: 总继承类，便于存放在一个list中
 */

public class MipsInstruction {

    @Override
    public String toString(){
        return "";
    }

    public int getOffset(){
        return 0;
    }

    public void setOffset(int offset){

    }
}
