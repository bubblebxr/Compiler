package LLVM;

import java.util.ArrayList;

public abstract class Type {
    public String toString(String name) {
        return null;
    }

    public String toString(ArrayList<Integer> valueList) {
        return null;
    }

    public Type getType(){return null;}
}
