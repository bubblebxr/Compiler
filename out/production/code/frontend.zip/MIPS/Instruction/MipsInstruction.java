package MIPS.Instruction;


/**
 * @className: MipsInstruction
 * @author: bxr
 * @date: 2024/11/21 20:45
 * @description: 总继承类，便于存放在一个list中
 */

public class MipsInstruction {

    @Override
    public String toString(){
        return "";
    }
}
